/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_parse;

import java.util.ArrayList;

public class Registro {

    public Registro Estructuras;
    public ArrayList LosDatos;

    public Registro() {
        this.Estructuras = Estructuras;
        this.LosDatos = new ArrayList();
    }

    public Registro getEstructuras() {
        return Estructuras;
    }

    public ArrayList getLosDatos() {
        return LosDatos;
    }

    public void addAll(Object[] datos) {
        for (Object obj : datos) {
            this.LosDatos.add(obj);
        }
    }

    public static Registro crearRegistro(Object... elementos) {
        Registro elem = new Registro();
        for (Object x : elementos) {
            verificar(x, elem);
        }
        return elem;

    }
    /*  @Override
     public String toString() {
     String datos="";
     for (Object obj : this.LosDatos) {
     datos = datos.concat(obj+", ");
     }
     return datos;
     }*/

    public static Registro verificar(Object x, Registro elem) {
        Object p = x.getClass().getName();
        if (p.equals(String.class)) {
            elem.Estructuras = (Registro) p;
            elem.LosDatos.add((Registro) x);
        } else if (p.equals(Interger.class)) {
            elem.Estructuras = (Registro) p;
            elem.LosDatos.add((Registro) x);
        } else if (p.equals(Double.class)) {
            elem.Estructuras = (Registro) p;
            elem.LosDatos.add((Registro) x);
        } else if (p.equals(Float.class)) {
            elem.Estructuras = (Registro) p;
            elem.LosDatos.add((Registro) x);
        } else if (p.equals(Boolean.class)) {
            elem.Estructuras = (Registro) p;
            elem.LosDatos.add((Registro) x);
        } else if (p.equals(Long.class)) {
            elem.Estructuras = (Registro) p;
            elem.LosDatos.add((Registro) x);
        }
        return elem;
    }

}
