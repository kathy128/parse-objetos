/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_parse;

import java.util.ArrayList;

public class Tabla {

    public int n;
    public Registro Estructuras;
    public ArrayList<Registro> Registros;
    public int cont = 0;

    public Tabla(int n, Registro Estructuras, ArrayList<Registro> Registros) {
        this.n = n;
        this.Estructuras = Estructuras;
        this.Registros = Registros;
    }

    public Tabla(Registro Estructura, Registro Registros) {
        this.n = n++;
        this.Estructuras = Estructura;
        this.Registros = new ArrayList();
        this.Registros.add(Registros);
    }

    public Registro getEstructuras() {
        return Estructuras;
    }

    public void addRegistro(Registro r) {
        Registros.add(r);
    }

    public String printRegistros() {
        String registros = "";
        for (Registro registro : this.Registros) {
            registros = registros.concat(registro + "\n");
        }
        return registros;
    }

    @Override
    public String toString() {
        return "Tabla " + n + "\n" + Estructuras + "\nRegistros:\n" + printRegistros();
    }
}
