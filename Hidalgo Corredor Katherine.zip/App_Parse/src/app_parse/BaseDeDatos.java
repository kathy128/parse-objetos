/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_parse;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author kathy queen
 */
public class BaseDeDatos {

    public ArrayList<Tabla> misTablas;
    public int k = 0, i = 0;

    public BaseDeDatos() {
        this.misTablas = new ArrayList();
    }

    public void addRegistro(Registro op) {
        Registro m = op.Estructuras;
        for (Tabla tablita : misTablas) {
            if(tablita.getEstructuras().equals(m)){
               tablita.addRegistro(m);
               return;
            }
        }
        k++;
        misTablas.add(new Tabla(op,m));
    }

    public void printAll() {
        System.out.println("Numero de tablas: " + k);
       for (Tabla tablita : misTablas){
        System.out.println("********************");
        System.out.println("Tabla # " + i);
           System.out.println(tablita);
    }
    }
   /*private void Existe(Tabla a) {
        Lista m = new Lista();
        for (Object x : m.miEstructura) {
            if (x.equals(a.Estructuras)) {
                m.LosDatos.add((Lista) a.Estructuras);
            }
        }
    }*/

}
